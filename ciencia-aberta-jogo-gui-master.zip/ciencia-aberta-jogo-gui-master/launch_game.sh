#!/usr/bin/env bash

pydm --hide-nav-bar --hide-menu-bar -m MOTOR=SOL3:DMC1:m8,VELO=IOC:m5,PONT1=IOC:m1,PONT2=IOC:m2,PONT3=IOC:m3,PONT4=IOC:m4 game.py ranking.txt
