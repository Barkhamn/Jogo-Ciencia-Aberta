import operator, os, json
from pydm import Display
from PyQt5.QtWidgets import QTableWidgetItem, QHeaderView, QTableView
from PyQt5.QtCore import Qt

class Ranking(object):
    """docstring for Ranking."""
    def __init__(self):
        super(Ranking, self).__init__()
        self.ranking_dict = {}

    def add_user_score(self, user, score):
        self.ranking_dict[user] = score

    def get_ordered_ranking(self):
        sorted_ranking = sorted(self.ranking_dict.items(), \
                                key=operator.itemgetter(1),
                                reverse=True)
        return sorted_ranking

    def print_ranking(self):
        print('RANKING:')
        sorted_ranking = self.get_ordered_ranking()
        for i in range(len(sorted_ranking)):
            print(sorted_ranking[i][0] + ' - ' + str(sorted_ranking[i][1]))

class RankingWindow(Display):
    """docstring forRankingWindow."""
    def __init__(self, args=None):
        super(RankingWindow , self).__init__(args=args, ui_filename='ranking.ui')
        self.ranking = Ranking()
        self.setup_ui()

        if len(args) == 0:
            print('ERROR: A filename to save ranking must be provided! Quitting.')
            exit()

        self.filename = args[0]
        if os.path.isfile(self.filename):
            print('INFO: Ranking filename exists! Loading it.')
            self.load_from_file(self.filename)

        #self.add('lais', 1)
        #self.add('luciano', 2)
        #self.add('gustavo', 4)
        #self.ranking.add_user_score('gabriel', 4)

    def setup_ui(self):
        self.headers = ['Usuário', 'Pontuação']
        self.tableRanking.setHorizontalHeaderLabels(self.headers)
        self.tableRanking.horizontalHeader().setResizeMode(QHeaderView.Stretch)
        self.tableRanking.setSelectionBehavior(QTableView.SelectRows)

    def add(self, user, score):
        self.ranking.add_user_score(user, score)
        self.save_to_file(self.filename)
        self.update_table()

    def update_table(self):
        self.tableRanking.clear()
        self.tableRanking.setHorizontalHeaderLabels(self.headers)

        sorted_ranking = self.ranking.get_ordered_ranking()
        for i in range(len(sorted_ranking)):
            print('adding')
            item_user = QTableWidgetItem(sorted_ranking[i][0])
            item_user.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            item_score = QTableWidgetItem(str(sorted_ranking[i][1]))
            item_score.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
            self.tableRanking.setRowCount(i + 1)
            self.tableRanking.setItem(i, 0, item_user)
            self.tableRanking.setItem(i, 1, item_score)

    def save_to_file(self, filename):
            with open(filename, 'w') as f:
                json.dump(self.ranking.ranking_dict, f)

    def load_from_file(self, filename):
        with open(filename, 'r') as f:
            loaded_ranking = json.loads(f.read())
        self.ranking.ranking_dict = loaded_ranking
        self.update_table()
        print(str(loaded_ranking))
