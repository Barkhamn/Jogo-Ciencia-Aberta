from pydm import Display
from PyQt5 import QtGui, QtCore
from PyQt5.QtCore import QProcess, Qt
from PyQt5.QtWidgets import QApplication
from random import randint
import time
import os
import epics
import qdarkstyle

DURATION_INT = 120
TARGET = 150
THIS_FOLDER = os.path.dirname(os.path.realpath(__file__))
MOTOR_VELO_LOWER = 4
MOTOR_VELO_UPPER = 6

class Game(Display):

    def onRefVeloChange(self, value, **kw):
        # Convert volts to motor velocity
        #motor_velo = 10 * value
        #self.pv_motor_velo.put(motor_velo)
        #self.lcd_beam.display(str(value))
        #self.lcd_scan.display(str(value))
        print('value = ' + str(value))

        if value > MOTOR_VELO_LOWER and value < MOTOR_VELO_UPPER:
            self._done = 1
            print('calibrando!!')
            self.label_calib_status.setText('Calibrado!')
        else:
            self._done = 0
            self.label_calib_status.setText('Calibrando')
        self.calibrado_sym.set_current_key(self._done)
        self.next_calib_btn.setEnabled(self._done)

    def __init__(self, parent=None, args=None, macros=None, ui_filename=None):
        super(Game, self).__init__(args=args, ui_filename='main_game.ui', macros=macros)

        self.setup_stylesheet()

        try:
            self.ranking_filename = args[0]
        except Exception as e:
            print('ERROR: Missing ranking filename.')
            #quit()

        self.macros = macros
        self.timer = None
        self.run = True
        self.load_images()
        self.lcd_time.display('--:--')
        self.pv_motor_velo = epics.PV(self.macros['MOTOR'] + '.VELO')
        self.pv_ref_velo = epics.PV(self.macros['VELO'], callback=self.onRefVeloChange)
        #Actions
        self.user_name_le.textChanged.connect(self.enter_user_name)
        self.iniciar_btn.clicked.connect(self.handleButton)
        self.next_calib_btn.clicked.connect(self.next_tab)
        self.next_feixe_btn.clicked.connect(self.next_tab_scan)
        self.salvar_1_btn.clicked.connect(self.raise_and_enable)
        self.button_collect_point.clicked.connect(self.collect_point)
        self.button_publish.clicked.connect(self.publish_article)
        self.button_restart.clicked.connect(self.init_game)

        # Load ranking display
        ranking_window = self.PyDMEmbeddedDisplay_ranking.app.open_file( \
                            'ranking.py', \
                            command_line_args=[self.ranking_filename])
        self.PyDMEmbeddedDisplay_ranking.embedded_widget = ranking_window

        self.init_game()

    def setup_stylesheet(self):
        pyqt5_dark_ss = qdarkstyle.load_stylesheet_pyqt5()
        app = QApplication.instance()
        app.setStyleSheet(pyqt5_dark_ss)

    def init_game(self):
        #Game parameters
        self.set_user('')
        self.set_score(0)
        self.time_left_int = DURATION_INT
        try:
            self.timer.stop()
        except:
            pass
        self.update_score_label()
        self.collected_points = 0
        self.lcd_collected.display(str(self.collected_points))
        self.points_score = []
        self.points_score.append(self.PyDMLabel_collection_partial_1)
        self.points_score.append(self.PyDMLabel_collection_partial_2)
        self.points_score.append(self.PyDMLabel_collection_partial_3)
        self.points_score.append(self.PyDMLabel_collection_partial_4)
        # Hide partial score labels
        self.PyDMLabel_collection_partial_text.setVisible(False)
        self.PyDMLabel_collection_partial_1.setVisible(False)
        self.PyDMLabel_collection_partial_2.setVisible(False)
        self.PyDMLabel_collection_partial_3.setVisible(False)
        self.PyDMLabel_collection_partial_4.setVisible(False)
        # Lock tabs
        self.tabWidget.setTabEnabled(0, True)
        self.tabWidget.setTabEnabled(1, False)
        self.tabWidget.setTabEnabled(2, False)
        self.tabWidget.setTabEnabled(3, False)
        self.tabWidget.setCurrentIndex(0)
        # Setup header
        self.label_status.setText('Feixe desligado')
        self.label_status.setStyleSheet('color: rgb(255, 0, 0);')
        self.lcd_time.display('--:--')
        # Setup instructions
        self.iniciar_btn.setEnabled(False)
        self.user_name_le.clear()
        # Setup phase 1
        self.label_calib_status.setText('Calibrando')
        self.calibrado_sym.set_current_key(0)
        self.next_calib_btn.setEnabled(False)
        # Setup phase 2
        self.next_feixe_btn.setEnabled(False)
        # Setup phase 3
        self.button_collect_point.setEnabled(True)
        self.button_publish.setEnabled(False)
        # Setup ranking
        self.PyDMEmbeddedDisplay_ranking.embedded_widget.label_message.setStyleSheet(
            'color: #2076db;')
        self.PyDMEmbeddedDisplay_ranking.embedded_widget.label_message.setText(
            'Complete o experimento e publique seu artigo. :)')

    def set_score(self, score):
        self.score = score
        self.update_score_label()

    def update_score_label(self):
        self.label_score.setText(str(self.score))

    def set_user(self, user):
        self.user = user
        self.user_name_label.setText(self.user)

    def enter_user_name(self, user):
        self.set_user(user)
        if user is None or user == '':
            self.iniciar_btn.setEnabled(False)
            return
        self.iniciar_btn.setEnabled(True)

    def timer_start(self):
        if not self.run:
            self.timer.stop()
            self.run = True
        else:
            self.run = False
        if self.timer == None:
            self.timer = QtCore.QTimer(self)
            self.timer.timeout.connect(self.timer_timeout)
        self.timer.start(1000)

        self.update_gui()

    def timer_timeout(self):
        if self.time_left_int <= 0:
            self.time_up()
            return
        self.time_left_int -= 1
        self.update_gui()

    def convert(self,seconds):
        return time.strftime("%H:%M:%S", time.gmtime(seconds))

    def update_gui(self):
        aa = self.convert(self.time_left_int)
        self.lcd_time.display(aa)

    def handleButton(self):
        self.label_status.setText('Feixe ligado')
        self.label_status.setStyleSheet('color: #2076db;')
        self.timer_start()
        self.tabWidget.setTabEnabled(1, True)
        self.tabWidget.setCurrentIndex(1)

    def load_images(self):
        byte_json = '{"0": "%s", "1": "%s"}'
        self.calibrado_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/cached0.svg', THIS_FOLDER + '/icons/checked.svg')
        self.sirius_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/sirius.png', THIS_FOLDER + '/icons/sirius.png')

        self.left_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/arrow-left.svg', THIS_FOLDER + '/icons/arrow-left-bold.svg')
        self.right_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/arrow-right-bold.svg', THIS_FOLDER + '/icons/arrow-right.svg')
        self.left_feixe_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/arrow-left.svg', THIS_FOLDER + '/icons/arrow-left-bold.svg')
        self.right_feixe_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/arrow-right-bold.svg', THIS_FOLDER + '/icons/arrow-right.svg')

        self.moving_feixe_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/cached1.svg', THIS_FOLDER + '/icons/cached0.svg')
        self.moving_sym.imageFiles = byte_json % (THIS_FOLDER + '/icons/cached1.svg', THIS_FOLDER + '/icons/cached0.svg')

    def next_tab(self):
        # Set motor velocity
        ref_velo = self.pv_ref_velo.get() 
        self.pv_motor_velo.put(ref_velo)

        self.tabWidget.setTabEnabled(2, True)
        self.tabWidget.setCurrentIndex(2)
        self.dir = 1
        self.move = True
        self.mover = epics.PV(self.macros['MOTOR'])
        self.stop = epics.PV(self.macros['MOTOR']+'.STOP')
        self.installEventFilter(self)

    def next_tab_scan(self):
        self.removeEventFilter(self)
        self.tabWidget.setTabEnabled(3, True)
        self.tabWidget.setCurrentIndex(3)
        self.installEventFilter(self)

    def raise_and_enable(self):
        # Update score
        calib_partial_score = self.PyDMLabel_calib_partial.text()
        score = float(calib_partial_score)
        self.set_score(score)
        # Goto fase 3
        self.next_feixe_btn.setEnabled(self._done)

    def collect_point(self):
        current_point_index = self.collected_points
        collection_partial_score = self.points_score[current_point_index].text()
        score = self.score + float(collection_partial_score)
        self.set_score(score)
        self.collected_points += 1
        self.lcd_collected.display(str(self.collected_points))

        if self.collected_points == 4:
            self.button_collect_point.setEnabled(False)
            self.button_publish.setEnabled(True)
            return

    def publish_article(self):
        # Goto to ranking tab
        self.timer.stop()
        self.PyDMEmbeddedDisplay_ranking.embedded_widget.add(self.user, self.score)
        self.tabWidget.setCurrentIndex(4)

        # Find and highlight user in ranking

        table = self.PyDMEmbeddedDisplay_ranking.embedded_widget.tableRanking
        items = table.findItems(self.user, Qt.MatchExactly)
        user_row = items[0].row()
        table.selectRow(user_row)

        self.PyDMEmbeddedDisplay_ranking.embedded_widget.label_message.setText(
            'Parabéns!\n\nSeu artigo foi publicado com sucesso!')

    def eventFilter(self, source, event):
        if event.type() == QtCore.QEvent.KeyPress:
            key = event.key()
            if key == QtCore.Qt.Key_Return:

                if self.move:
                    valor = TARGET*self.dir
                    self.dir = (-1) * self.dir
                    self.move = False
                    self.mover.put(valor)
                else:
                    self.move = True
                    self.stop.put(1)

        return super(Game, self).eventFilter(source, event)

    def time_up(self):

        self.PyDMEmbeddedDisplay_ranking.embedded_widget.label_message.setText(
            'Tempo esgotado.\n\nMas não desista!\nTente novamente para publicar o seu artigo. :)')

        self.tabWidget.setTabEnabled(0, False)
        self.tabWidget.setTabEnabled(1, False)
        self.tabWidget.setTabEnabled(2, False)
        self.tabWidget.setTabEnabled(3, False)

        self.label_status.setText('Feixe desligado')
        self.label_status.setStyleSheet('color: rgb(255, 0, 0);')

        self.tabWidget.setCurrentIndex(4)
